//
//  HPSchemaV01_00_00.swift
//  HuliPizzaPersistent
//
//  Created by Steven Lipton on 2/12/24.
//

import Foundation
import SwiftData

enum HPSchemaV01_00_00:VersionedSchema{
    static var models: [any PersistentModel.Type]{
        [OrderTicket.self,OrderItem.self,NameModel.self,RatingModel.self]
    }
    
    static var versionIdentifier: Schema.Version = Schema.Version(1,0,0)
    
    
}
